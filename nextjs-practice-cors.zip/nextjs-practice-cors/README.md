# Rent A Car Project

Crearemos un una web para simulando una empresa de rent a car.

La web tendrá una las siguientes secciones

- [Home page](./doc/home.md)
- [Booking process](./doc/booking-process.md)
- [Customer área](./doc/customer-area.md)
- [Car list](./doc/car-list.md)
- [General layout](./doc/general-layout.md)

## Tecnologías y herramientas de desarrollo

- [next js](https://nextjs.org/docs): Como framework de react. Si queréis crear la api en next también podéis hacerlo o bien utilizar la de .net core que habéis creado.
- [react](https://react.dev/): Como librería de componentes.
- [css modules](https://nextjs.org/docs/advanced-features/customizing-postcss-config#css-modules): Para los componentes utilizaremos css modules. Además por rápidez y facilidad de desarrollo utilizaremos un framework css como [tailwind](https://tailwindcss.com/) o [bootstrap](https://getbootstrap.com/docs/5.3/getting-started/introduction/). Ambos tienen librería de componentes con los estilos ya aplicados para agilizar el desarrollo.
- [react hook form](https://react-hook-form.com/): Para la gestión de formularios.
- [days js](https://day.js.org/): Para la gestión de fechas.
- [redux](https://redux-toolkit.js.org/): Para la gestión del estado de la aplicación.
- [jest](https://jestjs.io/): Para los test unitarios.
- [Typescript](https://www.typescriptlang.org/): Como lenguaje de programación.
- [eslint](https://eslint.org/): Para el lintado del código.
- [prettier](https://prettier.io/): Para el formateo del código.

## Proceso de desarrollo

- Separar las tareas entre los 4 desarrolladores.
- Cada desarrollador creará una rama con el nombre de la feature que este desarrollando. [Git feature branch workflow](https://www.atlassian.com/git/tutorials/comparing-workflows/feature-branch-workflow).
- Repartir entre vosotros las features que hay (Proceso de reserva, área de clientes, listado de coches, etc).

## Antes de empezar

Revisar la documentación de next js para familiarizarse con el framework. Lo más importante es saber como funciona el sistema de rutas y la formas que tiene de renderizar el contenido.
