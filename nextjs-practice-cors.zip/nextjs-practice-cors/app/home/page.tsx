'use client';
import { Provider } from 'react-redux';
import { store } from '~/store';
import HomeForm from '~/components/home/HomeForm';

export default function Coches() {
	return (
		<>
			<Provider store={store}>
				<HomeForm />
			</Provider>
		</>
	);
}
