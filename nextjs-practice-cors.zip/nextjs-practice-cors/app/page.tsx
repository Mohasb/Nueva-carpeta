'use client';

import { useState } from 'react';
import { ICar } from '~/models/models';

export default function Page() {
	const [text, setText] = useState('');

	async function postCar(obj: ICar) {
		await fetch('api/car', {
			method: 'POST',
			body: JSON.stringify(obj),
		});
	}

	function handler() {
		const obj: ICar = {
			id: 99,
			model: 'Opel Corsaaaaaa',
			automatic: true,
			licensePlate: '1234ABC',
			doors: 5,
			seats: 5,
			gasType: 'Gasoil',
			suitcases: 2,
			dayPrice: 20,
			groupId: 1,
			branchId: 1,
		};

		void postCar(obj);
	}

	return (
		<div>
			<h1>Prueba</h1>
			<form>
				<input
					type="text"
					id="textInput"
					onChange={(e) => setText(e.target.value)}
				></input>
				<input type="button" value="enviar" onClick={handler}></input>
			</form>
			<p>{text}</p>
		</div>
	);
}
