'use client';
import useClientData from '~/hooks/useClientData';
import { ICard } from '~/models/card_model';
import { IClient } from '~/models/client_model';

export default function Page() {
	const client: IClient = useClientData()!;
	async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
		e.preventDefault();

		const form = e.currentTarget;
		const formData = new FormData(form);

		const card: ICard = {
			id: 0,
			numberCode: formData.get('numberCode') as unknown as number,
			expirationDate: formData.get('expirationDate') as unknown as Date,
			ownerName: client.name + ' ' + client.surname,
			client: client.dni,
		};

		const requestOptions = {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify(card),
		};
		await fetch(`http://localhost:5230/api/Card/`, requestOptions);
		alert('Tarjeta añadida correctamente');
		console.log(card);
		window.location.href = '/profile/data';
	}
	return (
		// eslint-disable-next-line @typescript-eslint/no-misused-promises
		<form onSubmit={handleSubmit}>
			<h1>Añadir una tarjeta:</h1>
			<label>Número de tarjeta: </label>
			<input name="numberCode" type="number" />
			<br />
			<label>Fecha de expiración: </label>
			<input name="expirationDate" type="date" />
			<br />
			<input type="submit" value="Añadir" />
		</form>
	);
}
