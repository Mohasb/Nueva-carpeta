'use client';

import useClientData from '~/hooks/useClientData';
import useAllBookingsByClientData from '~/hooks/useAllBookingsByClientData';
import { IClient } from '~/models/client_model';
import { IBooking } from './../../src/models/booking_model';

export default function Page() {
	// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
	const client: IClient = useClientData()!;

	const bookings: IBooking[] = useAllBookingsByClientData();
	const bookingsHtml = bookings.map((booking) => {
		return (
			<tbody key={booking.id}>
				<tr>
					<th scope="row">{booking.id}</th>
					<td>{booking.dayEnd.toString()}</td>
					<td>{booking.dayStart.toString()}</td>
					<td>{booking.pickUp}</td>
					<td>{booking.dropOff}</td>
					<td>{booking.licensePlate}</td>
					{/* <td>{booking.status}</td> */}
				</tr>
			</tbody>
		);
	});

	if (bookings.length > 0) {
		return (
			<div>
				<h1>Bienvenido, {client && client.name}</h1>
				<h2>Tus reservas:</h2>
				<table>
					<thead>
						<tr>
							<th scope="col">#</th>
							<th scope="col">Fecha inicial</th>
							<th scope="col">Fecha final</th>
							<th scope="col">Sucursal de recogida</th>
							<th scope="col">Sucursal de devolución</th>
							<th scope="col">Matrícula</th>
							{/* <th scope="col">Estado</th> */}
						</tr>
					</thead>
					{bookingsHtml}
				</table>
			</div>
		);
	} else {
		return (
			<div>
				<h1>Bienvenido, {client && client.name}</h1>
				<h2>Todavía no tienes reservas</h2>
			</div>
		);
	}
}
