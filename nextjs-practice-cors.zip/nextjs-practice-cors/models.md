## Una vista de los diferentes modelos que tendremos

### Client Model:
- Id       : Number
- DNI      : String
- Name     : String
- Surname  : String
- Email    : String
- Password : String
- Phone    : Number
- Address  : String
- CP       : Number
- City     : String
- Country  : String

### Card Model:
- Id             : Number
- NumberCode     : Number
- ExpirationDate : Date
- OwnerName      : String
- ClientId       : Number

### Branch Model:
- Id   : Number
- Name : String

### Group Model:
- Id    : Number
- Name  : String
- Photo : String

### Booking Model:
- Id           : Number
- Pickup       : String
- Dropoff      : String
- DayStart     : Date
- HourStart    : String
- DayEnd       : Date
- HourEnd      : String
- GroupId      : Number
- LicencePlate : String
- ClientId     : Number
- CardId       : Number

### Car Model:
- Model        : String
- Automatic    : Boolean
- LicencePlate : String
- Doors        : Number
- Seats        : Number
- GasType      : String
- Suitcases    : Number
- DayPrice     : Number
- GroupId      : Number
- BranchId     : Number

### Planning Model:
- DayHour   : Date
- Branch    : String
- Group     : String
- Available : Number





## Sistemas de carpetas src

### Components
 - Guardamos todos los componentes que podamos crear, tanto los unitarios (botones, inputs, partes de una tablla,...) como los colectivos (el contexto de las páginas para poder proveer en las propias páginas la store con las variables).
 - Un archivo llamada 'componentes' el cuál se usará como barril de imports y exports para poder importar cuantos componentes sean en otro archivo desde el mismo.

### Hooks
 - Recopila todos los hooks personalizados, cada uno siendo llamado en archivos separados (como son el que recibe todas las sucursales, los grupos,...).
 - También guardamos un archivo 'store' que cuenta con el 'useDispatch' y 'useSelector' que nos permiten utilizar redux y almacenar y recuperar datos de la 'storage'.
 - Un archivo barril 'hooks' para hacer los imports en uno mismo.

### Interfaces
 - Dado que pasamos por parámetro diferentes variables, en lugar de tipar cada uno de sus parámetros, creamos una interfaz asociada para cada componente que corresponda.
 - Al igual que el resto de carpetas, tenemos el archivo barril 'interfaces'.

### Models
 - Utiliza interfaces pero esta carpeta va dedicada a tipar con interfaces los datos que creamos, recibimos y enviamos, tanto en el frontend como el backend.
 - Archivo barril 'models'

### Services
 - Todas las llamadas a la api (cualquier función que utilice fetch) se situan en esta carpeta.
 - Archivo barril 'services'

### Store
 - Tenemos el archivo store que sirve de mediador para llamar a los diferentes 'slices', las cuales cada una corresponde a una variable distinta. Es por ello que se integran en carpetas denominadas por el propio tipo de variable.

### Styles
 - Todos los estilos de css serán integrados en esta carpeta.

### Utils
 - Por el momento la única carpeta que encontramos es 'constants', donde tendremos las constantes que se consideren de variables de uso global (como el inicio de las rutas del fetch, constantes de inicialización de variables locales,...)


