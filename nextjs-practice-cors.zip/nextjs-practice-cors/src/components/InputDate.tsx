import { IInputDate } from '~/interfaces/interfaces';

export default function InputDate({
	value,
	placeholder,
	onChange,
	style,
}: IInputDate) {
	return (
		<input
			type="date"
			value={value}
			placeholder={placeholder}
			onChange={onChange}
			style={style}
		/>
	);
}
