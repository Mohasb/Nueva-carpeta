import { useDispatch } from 'react-redux';
import { useAppSelector } from '~/hooks/store';
import { IBookingPost } from '~/models/booking_post_model';
import { addBooking } from '~/store/booking/slice';
import { selectGroupState } from '~/store/groups/slice';

export default function GroupContent() {
	const groups = useAppSelector(selectGroupState).groups;
	const dispatch = useDispatch();

	const onClick: React.MouseEventHandler<HTMLButtonElement> = (event) => {
		console.log(event.currentTarget);
		const group = event.currentTarget.value;
		console.log(group);
		const savedBooking: IBookingPost = JSON.parse(
			// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
			localStorage.getItem('_booking')!
		);
		savedBooking.group = group;
		dispatch(addBooking(savedBooking));
	};

	return (
		<>
			<div>
				<h1>Lista Grupos</h1>

				{Object.values(groups).map((group, index) => (
					<button key={index} onClick={onClick} value={group.group}>
						{group.group}
					</button>
				))}
			</div>
		</>
	);
}
