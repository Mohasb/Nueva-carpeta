import { log } from 'console';
import { useRouter } from 'next/navigation';
import { useAppDispatch } from '~/hooks/store';
import { IClient } from '~/models/client_model';
import { requestPostClient } from '~/services/services';
import { login } from '~/store/login/slice';
import { INITIAL_CLIENT_STATE } from '~/utils/constants/constants';

export default function LoginForm() {
	const dispatch = useAppDispatch();
	const router = useRouter();

	const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();
		const form = event.currentTarget;
		const formData = new FormData(form);

		const loggedClient: IClient = await requestPostClient(
			formData.get('dni') as string,
			formData.get('password') as string
		);

		if (loggedClient != INITIAL_CLIENT_STATE) {
			dispatch(login(loggedClient));
			router.push('/home');
		}
	};

	return (
		<>
			<form onSubmit={handleSubmit}>
				DNI <br />
				<input name="dni" type="text" />
				<br />
				Password
				<br />
				<input name="password" type="password" />
				<br />
				<button type="submit">Login</button>
			</form>
		</>
	);
}
