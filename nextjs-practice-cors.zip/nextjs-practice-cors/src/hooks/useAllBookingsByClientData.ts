import { useState, useEffect } from 'react';
import { IBooking, IClient } from '~/models/models';

export default function useAllBookingsByClientData() {
	const [bookings, setBookings] = useState<IBooking[]>([]);
	const token: string = JSON.parse(
		localStorage.getItem('logged__user')!
	)?.token;
	const clientDni: string =
		// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
		(JSON.parse(localStorage.getItem('logged__user')!) as IClient)?.dni;

	useEffect(() => {
		async function getBookings() {
			const requestOptions = {
				headers: new Headers({
					Authorization: 'Bearer ' + token,
				}),
			};
			const response = await fetch(
				`http://localhost:5230/api/Booking/clientBookings/${clientDni}`,
				requestOptions
			);

			const data: IBooking[] = await response.json();
			setBookings(data);
		}
		void getBookings();
	}, []);
	return bookings;
}
