import { useEffect, useState } from 'react';
import { ICard, IClient } from '~/models/models';

export default function useAllCardsByClient() {
	const [cards, setCards] = useState<ICard[]>([]);
	const token: string = JSON.parse(
		localStorage.getItem('logged__user')!
	)?.token;
	const clientDni: string =
		// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
		(JSON.parse(localStorage.getItem('logged__user')!) as IClient)?.dni;

	useEffect(() => {
		async function getCards() {
			const requestOptions = {
				headers: new Headers({
					Authorization: 'Bearer ' + token,
				}),
			};
			const response = await fetch(
				`http://localhost:5230/api/Card/client/${clientDni}`,
				requestOptions
			);
			const data: ICard[] = await response.json();
			setCards(data);
		}
		void getCards();
	}, []);

	return cards;
}
