import { useEffect, useState } from 'react';
import { IAvailable } from '~/models/models';
import { getAllGroupsAvailable } from '~/services/services';

export default function useAllCarsData(
	PickUp: string,
	DateStart: string,
	DateEnd: string
): IAvailable[] {
	const [groups, setGroup] = useState<IAvailable[]>([]);

	useEffect(() => {
		async function getData() {
			const respuesta = await getAllGroupsAvailable(PickUp, DateStart, DateEnd);

			console.log(respuesta);

			setGroup(respuesta);
		}

		void getData();
	}, []);

	return groups;
}
