/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { useEffect, useState } from 'react';
import { IClient } from '~/models/models';

export default function useClientData() {
	const [client, setClient] = useState<IClient>();

	useEffect(() => {
		// eslint-disable-next-line @typescript-eslint/no-unsafe-member-access, @typescript-eslint/no-non-null-assertion
		const clientDni: string = JSON.parse(
			localStorage.getItem('logged__user')!
		)?.dni;
		const token: string = JSON.parse(
			localStorage.getItem('logged__user')!
		)?.token;

		async function getClient() {
			const requestOptions = {
				headers: new Headers({
					Authorization: 'Bearer ' + token,
				}),
			};
			const response = await fetch(
				`http://localhost:5230/api/Client/${clientDni}`,
				requestOptions
			).catch(() => {
				window.location.href = '/login';
			});
			// eslint-disable-next-line @typescript-eslint/no-unsafe-call
			const data: IClient = await response.json();
			setClient(data);
		}
		void getClient();
	}, []);
	return client;
}
