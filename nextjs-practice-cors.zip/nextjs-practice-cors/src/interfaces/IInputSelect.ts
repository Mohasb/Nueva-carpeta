import { CSSProperties } from 'react';

export interface IInputSelect {
	style?: CSSProperties | undefined;
	value: string;
	dataList: string[];
}
