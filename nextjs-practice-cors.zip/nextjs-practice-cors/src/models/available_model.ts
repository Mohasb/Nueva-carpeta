export interface IAvailable {
	group: string;
	available_: number;
}
