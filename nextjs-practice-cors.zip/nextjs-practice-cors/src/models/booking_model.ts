export interface IBooking {
	id: number;
	pickUp: string;
	dropOff: string;
	dayStart: Date;
	hourStart: string;
	dayEnd: Date;
	hourEnd: string;
	groupId: number;
	licensePlate: string;
	clientId: number;
	cardId: number;
}
