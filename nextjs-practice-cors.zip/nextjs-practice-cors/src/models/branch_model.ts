export interface IBranch {
	name: string;
}
