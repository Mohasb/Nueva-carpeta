import { IBooking } from './booking_model';
import { IBranch } from './branch_model';
import { ICar } from './car_model';
import { ICard } from './card_model';
import { IClient } from './client_model';
import { IGroup } from './group_model';
import { IPlanning } from './planning_model';
import { IAvailable } from './available_model';
import { IBookingPost } from './booking_post_model';

export type {
	IBooking,
	IBookingPost,
	IBranch,
	ICar,
	ICard,
	IClient,
	IGroup,
	IPlanning,
	IAvailable,
};
