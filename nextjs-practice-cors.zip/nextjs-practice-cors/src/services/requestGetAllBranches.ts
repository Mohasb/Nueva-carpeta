import { IBranch } from '~/models/models';
import { IP } from '~/utils/constants/constants';

export async function getAllBranches(): Promise<IBranch[]> {
	return fetch(`${IP}/Branch`, { method: 'GET' })
		.then(async (response) => {
			if (response.status != 200) throw new Error();
			return response.json();
		})
		.then((res: IBranch[]) => {
			return res;
		})
		.catch(() => []);
}
