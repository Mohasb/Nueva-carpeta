export { requestPostClient } from './requestPostClient';

export { getAllGroupsAvailable } from './requestGetGroupAvailables';

export { getAllBranches } from './requestGetAllBranches';
