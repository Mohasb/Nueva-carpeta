import { configureStore } from '@reduxjs/toolkit';
import loginReducer from './login/slice';
import groupReducer from './groups/slice';
import bookingReducer from './booking/slice';

export const store = configureStore({
	reducer: {
		login: loginReducer,
		groups: groupReducer,
		booking: bookingReducer,
	},
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
