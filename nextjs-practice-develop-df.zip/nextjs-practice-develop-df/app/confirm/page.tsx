'use client';

import ConfirmContent from '~/components/confirm/ConfirmContent';

export default function Confirm() {
	return <ConfirmContent />;
}
