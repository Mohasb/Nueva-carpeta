'use client';

import GroupContent from '~/components/groups/GroupContent';

export default function Groups() {
	return <GroupContent />;
}
