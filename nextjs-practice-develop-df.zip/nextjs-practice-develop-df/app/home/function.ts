import { Dispatch, SetStateAction } from 'react';
import { IBookingPost } from '~/models/booking_post_model';
import { getAllGroupsAvailable } from '~/services/services';
import { AppDispatch } from '~/store';
import { addBooking } from '~/store/booking/slice';

export function getSevenDaysLater(day: string) {
	const newDate = new Date(day);
	newDate.setDate(newDate.getDate() + 7);
	return newDate.toISOString().substring(0, 10);
}

export function createHourList() {
	const hourList: string[] = [];
	for (let i = 0; i < 24; i++) {
		const minuteList: string[] = ['00', '30'];
		minuteList.forEach((minutes) => {
			if (i < 10) hourList.push(`0${i}:${minutes}`);
			else hourList.push(`${i}:${minutes}`);
		});
	}

	return hourList;
}

export default function onChecked(
	event: React.ChangeEvent<HTMLInputElement>,
	setCheck: Dispatch<SetStateAction<boolean>>
) {
	setCheck(event.target.checked);
}

export function onDayStartChange(
	event: React.ChangeEvent<HTMLInputElement>,
	setDayStart: Dispatch<SetStateAction<string>>,
	dayEnd: string,
	setDayEnd: Dispatch<SetStateAction<string>>
) {
	const newDayStart = new Date(event.target.value).setHours(0, 0, 0, 0);

	if (newDayStart >= new Date().setHours(0, 0, 0, 0))
		setDayStart(event.target.value);

	if (newDayStart >= Date.parse(dayEnd))
		setDayEnd(getSevenDaysLater(new Date(event.target.value).toISOString()));
}

export function onDayEndChange(
	event: React.ChangeEvent<HTMLInputElement>,
	dayStart: string,
	setDayEnd: Dispatch<SetStateAction<string>>
) {
	const newDayEnd = new Date(event.target.value).setHours(0, 0, 0, 0);

	if (
		newDayEnd >= new Date().setHours(0, 0, 0, 0) &&
		newDayEnd >= Date.parse(dayStart)
	)
		setDayEnd(event.target.value);
}

export async function onSubmit(
	pickUp: string,
	dropOff: string,
	hourStart: string,
	hourEnd: string,
	dayStart: string,
	dayEnd: string,
	dispatch: AppDispatch,
	booking: IBookingPost
) {
	if (dropOff == '') dropOff = pickUp;

	const DateStart = `${dayStart}T${hourStart}:00Z`;
	const DateEnd = `${dayEnd}T${hourEnd}:00Z`;

	dispatch(
		addBooking({
			pickUp,
			dropOff,
			dateStart: DateStart,
			dateEnd: DateEnd,
			group: booking.group,
			client: booking.client,
			card: booking.card,
		})
	);

	return getAllGroupsAvailable(pickUp, DateStart, DateEnd);
}
