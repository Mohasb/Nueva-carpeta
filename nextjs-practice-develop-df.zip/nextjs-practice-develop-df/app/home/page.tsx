'use client';

import HomeForm from '~/components/home/HomeForm';

export default function Coches() {
	return <HomeForm />;
}
