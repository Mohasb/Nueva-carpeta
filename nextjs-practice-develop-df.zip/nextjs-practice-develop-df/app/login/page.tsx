'use client';

import UserData from '~/components/login/UserData';
import LoginForm from '~/components/login/LoginForm';
import { Title } from '@tremor/react';

export default function Login() {
	return (
		<>
			<Title>Login</Title>

			<UserData />
			<LoginForm />
		</>
	);
}
