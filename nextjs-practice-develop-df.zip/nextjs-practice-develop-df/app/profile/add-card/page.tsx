'use client';
import { Button, TextInput, Title } from '@tremor/react';
import { useRouter } from 'next/navigation';
import useGetDataBooking from '~/hooks/useGetDataBooking';
import useGetDataClient from '~/hooks/useGetDataClient';
import { IBookingPost } from '~/models/booking_post_model';
import { ICard } from '~/models/card_model';
import { IClient } from '~/models/client_model';
import { postCard } from '~/services/services';
import {
	INITIAL_BOOKING_STATE,
	INITIAL_CARD_STATE,
} from '~/utils/constants/constants';

export default function Page() {
	const router = useRouter();
	const client: IClient = useGetDataClient();
	const booking: IBookingPost = useGetDataBooking();

	const doPost = async (numberCode: number, expirationDate: Date) => {
		const card: ICard = {
			numberCode,
			expirationDate,
			ownerName: client.name + ' ' + client.surname,
			client: client.dni,
		};

		const postedCard = await postCard(card);
		if (postedCard == INITIAL_CARD_STATE) router.push('/login');
		else if (booking != INITIAL_BOOKING_STATE && booking.group != '')
			router.push('/confirm');
		else router.push('/profile/data');
	};

	function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
		e.preventDefault();
		const form = e.currentTarget;
		const formData = new FormData(form);

		const x = (formData.get('expirationDate') as string).split('/');
		const date = `${x[1]}-${x[0]}-01`;

		void doPost(
			formData.get('numberCode') as unknown as number,
			date as unknown as Date
		);
	}

	return (
		<form onSubmit={handleSubmit} style={{ width: '300px', margin: '20px' }}>
			<Title>Añadir una tarjeta:</Title>
			<TextInput
				name="numberCode"
				type="text"
				placeholder="Número de tarjeta..."
			/>
			<TextInput
				name="expirationDate"
				type="text"
				placeholder="Fecha de expiración (mm/yyyy)..."
			/>
			<Button type="submit">Añadir</Button>
		</form>
	);
}
