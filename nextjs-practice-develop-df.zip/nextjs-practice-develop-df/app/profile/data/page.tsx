/* eslint-disable react-hooks/rules-of-hooks */
'use client';
import useDeleteCard from '~/hooks/useDeleteCard';
import { IClient } from '~/models/client_model';
import Link from 'next/link';
import useGetDataClient from '~/hooks/useGetDataClient';
import { ICard } from '~/models/card_model';
import useGetCards from '~/hooks/useGetCards';
import {
	Button,
	Card,
	List,
	ListItem,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeaderCell,
	TableRow,
	Title,
} from '@tremor/react';

export default function Page() {
	const client: IClient = useGetDataClient();
	const cards: ICard[] = useGetCards(client);

	const deleteCard: React.MouseEventHandler<HTMLButtonElement> = (e) => {
		if (confirm('Seguro que quieres eliminar la tarjeta?')) {
			useDeleteCard(e.currentTarget.value, client.token);
			window.location.reload();
		}
	};

	const cardsHtml = cards.map((card) => {
		const expiration = new Date(card.expirationDate).toLocaleDateString();
		const numberCode: string = card.numberCode.toString().slice(-4);
		return (
			<ListItem key={card.id}>
				<div>
					<strong>Número de tarjeta:</strong> **** **** **** {numberCode}
					<br />
					<strong>Titular:</strong> {card.ownerName}
					<br />
					<strong>Fecha de caducidad:</strong> {expiration}
					<br />
					<Button value={card.id} onClick={(e) => deleteCard(e)}>
						Eliminar
					</Button>
				</div>
			</ListItem>
		);
	});

	if (client) {
		return (
			<>
				<Card style={{ margin: '20px', width: '80%' }}>
					<Title>
						{client.name} {client.surname}
					</Title>
					<Table>
						<TableHead>
							<TableRow>
								<TableHeaderCell> DNI </TableHeaderCell>
								<TableHeaderCell> Edad </TableHeaderCell>
								<TableHeaderCell> Dirección </TableHeaderCell>
								<TableHeaderCell> Teléfono </TableHeaderCell>
								<TableHeaderCell> Email: </TableHeaderCell>
							</TableRow>
						</TableHead>

						<TableBody>
							<TableRow>
								<TableCell>{client.dni}</TableCell>
								<TableCell>{client.age}</TableCell>
								<TableCell>
									{client.address}, {client.cp}, {client.city}, {client.country}
								</TableCell>
								<TableCell>{client.phone}</TableCell>
								<TableCell>{client.email}</TableCell>
							</TableRow>
						</TableBody>
					</Table>
				</Card>

				<Button style={{ marginLeft: '20px' }}>
					<Link href="/profile/data/update">Editar mis datos personales</Link>
				</Button>

				<Card style={{ margin: '20px', width: '80%' }}>
					<Title>Tarjetas</Title>

					<List>
						{cardsHtml.length ? (
							cardsHtml
						) : (
							<ListItem>No tienes tarjetas</ListItem>
						)}
					</List>
				</Card>

				<Button style={{ marginLeft: '20px' }}>
					<Link href="/profile/add-card">Añadir tarjeta</Link>
				</Button>
			</>
		);
	}
}
