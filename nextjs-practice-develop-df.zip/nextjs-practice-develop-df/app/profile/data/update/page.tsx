'use client';

import {
	Button,
	Card,
	Table,
	TableBody,
	TableCell,
	TableRow,
	TextInput,
	Title,
} from '@tremor/react';
import { useRouter } from 'next/navigation';
import { useDispatch } from 'react-redux';
import { UpdateClientRow } from '~/components/profile/UpdateClientInput';
import useGetDataClient from '~/hooks/useGetDataClient';
import { IClient } from '~/models/client_model';
import { updateClient } from '~/services/requestUpdateClient';
import { login } from '~/store/login/slice';
import { INITIAL_CLIENT_STATE } from '~/utils/constants/constants';

export default function Page() {
	const dispatch = useDispatch();
	const client: IClient = useGetDataClient();
	const router = useRouter();

	const doUpdate = async (uClient: IClient) => {
		const updatedClient: IClient = await updateClient(uClient);

		if (updatedClient == INITIAL_CLIENT_STATE) router.push('/login');

		updatedClient.token = client.token;
		dispatch(login(updatedClient));
		router.push('/profile/data');
	};

	function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
		e.preventDefault();
		const form = e.currentTarget;
		const formData = new FormData(form);
		const uClient: IClient = {
			dni: formData.get('dni') as string,
			name: formData.get('name') as string,
			surname: formData.get('surname') as string,
			age: formData.get('age') as unknown as number,
			email: formData.get('email') as string,
			password: formData.get('password') as string,
			phone: formData.get('phone') as unknown as number,
			address: formData.get('address') as string,
			cp: formData.get('cp') as unknown as number,
			city: formData.get('city') as string,
			country: formData.get('country') as string,
		};

		void doUpdate(uClient);
	}

	if (client) {
		return (
			<form onSubmit={handleSubmit} className="update-client-data-form">
				<Card style={{ margin: '20px', width: '50%' }}>
					<Title>Editar datos personales:</Title>

					<Table>
						<TableBody>
							<UpdateClientRow
								field="Nombre"
								name="name"
								defaultValue={client.name}
							/>
							<UpdateClientRow
								field="Apellidos"
								name="surname"
								defaultValue={client.surname}
							/>
							<UpdateClientRow
								field="DNI"
								name="dni"
								defaultValue={client.dni}
							/>
							<UpdateClientRow
								field="Edad"
								name="age"
								defaultValue={client.age.toString()}
							/>
							<UpdateClientRow
								field="Dirección"
								name="address"
								defaultValue={client.address}
							/>
							<UpdateClientRow
								field="Ciudad"
								name="city"
								defaultValue={client.city}
							/>
							<UpdateClientRow
								field="País"
								name="country"
								defaultValue={client.country}
							/>
							<UpdateClientRow
								field="Código postal"
								name="cp"
								defaultValue={client.cp.toString()}
							/>
							<UpdateClientRow
								field="Teléfono"
								name="phone"
								defaultValue={client.phone.toString()}
							/>
							<UpdateClientRow
								field="Email"
								name="email"
								defaultValue={client.email}
							/>
							<TableRow>
								<TableCell>Contraseña:</TableCell>
								<TableCell>
									<TextInput name="password" type="password" />
								</TableCell>
							</TableRow>
						</TableBody>
					</Table>
					<Button type="submit" style={{ marginTop: '10px' }}>
						Editar
					</Button>
				</Card>
			</form>
		);
	}
}
