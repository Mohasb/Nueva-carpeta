'use client';

import { IClient } from '~/models/client_model';
import { useState } from 'react';
import useGetDataClient from '~/hooks/useGetDataClient';
import useGetBooking from '~/hooks/useGetBooking';
import {
	Card,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeaderCell,
	TableRow,
	Title,
} from '@tremor/react';

export default function Page() {
	const client: IClient = useGetDataClient();
	const [loading, setLoading] = useState(true);
	const bookings = useGetBooking(client, setLoading);

	const bookingsHtml = bookings.map((booking) => {
		return (
			<TableRow key={booking.id}>
				<TableHeaderCell>{booking.id}</TableHeaderCell>
				<TableCell>{booking.dateStart.toString()}</TableCell>
				<TableCell>{booking.dateEnd.toString()}</TableCell>
				<TableCell>{booking.pickUp}</TableCell>
				<TableCell>{booking.dropOff}</TableCell>
				<TableCell>{booking.licensePlate}</TableCell>
			</TableRow>
		);
	});

	return (
		<>
			<Card style={{ margin: '20px', width: '80%' }}>
				<Title>Bienvenido, {client && client.name}</Title>
				{loading ? (
					<p>Loading...</p>
				) : (
					<>
						{bookings.length == 0 ? (
							<Title>Todavía no tienes reservas</Title>
						) : (
							<>
								<Title>Tus reservas:</Title>
								<Table>
									<TableHead>
										<TableRow>
											<TableHeaderCell>#</TableHeaderCell>
											<TableHeaderCell>Fecha inicial</TableHeaderCell>
											<TableHeaderCell>Fecha final</TableHeaderCell>
											<TableHeaderCell>Sucursal de recogida</TableHeaderCell>
											<TableHeaderCell>Sucursal de devolución</TableHeaderCell>
											<TableHeaderCell>Matrícula</TableHeaderCell>
										</TableRow>
									</TableHead>
									<TableBody>{bookingsHtml}</TableBody>
								</Table>
							</>
						)}
					</>
				)}
			</Card>
		</>
	);
}
