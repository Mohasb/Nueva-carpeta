# Common

Todas las páginas tendrán un diseño común. Investigar [como crear un layout común para todas las páginas en next js](https://nextjs.org/docs/basic-features/layouts)

## Header

El header tendrá el logo a la izquierda y un menú de navegación a la derecha con las siguientes opciones:

- Offices
- Fleet
- My account

## Footer

Mostrará la información de contacto de la empresa y las redes sociales.
