# Home

- Mostraremos el formulario para iniciar el proceso de reserva.

- Mostraremos un listado de coches destacados, al pulsar sobre el coche mostraremos toda la información de este.
