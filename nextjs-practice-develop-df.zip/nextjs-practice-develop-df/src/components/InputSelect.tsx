import { SelectBox, SelectBoxItem } from '@tremor/react';
import { IInputSelect } from '~/interfaces/interfaces';

export default function InputSelect({
	style,
	dataList,
	value,
	setValue,
}: IInputSelect) {
	return (
		<>
			<SelectBox style={style} value={value} onValueChange={setValue}>
				{dataList.map((element, index) => (
					<SelectBoxItem key={index} value={element} text={element} />
				))}
			</SelectBox>
		</>
	);
}
