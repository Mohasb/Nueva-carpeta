import { IClient } from '~/models/client_model';
import { login } from '~/store/login/slice';
import { useAppDispatch } from '~/hooks/store';

export default function Preloader() {
	const dispatch = useAppDispatch();
	const lsData = window.localStorage.getItem('logged__user');
	if (lsData != null) {
		const lsClient = JSON.parse(lsData) as IClient;
		dispatch(login(lsClient));
	}

	return null;
}
