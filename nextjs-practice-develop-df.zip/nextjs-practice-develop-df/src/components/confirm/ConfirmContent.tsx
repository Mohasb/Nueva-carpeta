import {
	Table,
	TableRow,
	TableCell,
	TableHead,
	TableHeaderCell,
	TableBody,
	Button,
} from '@tremor/react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useGetCards, useGetDataClient } from '~/hooks/hooks';
import useGetDataBooking from '~/hooks/useGetDataBooking';
import { IBookingPost } from '~/models/booking_post_model';
import { ICard, IClient } from '~/models/models';
import { postBooking } from '~/services/services';
import { addBooking } from '~/store/booking/slice';
import { INITIAL_BOOKING_STATE } from '~/utils/constants/constants';

export default function ConfirmContent() {
	const booking: IBookingPost = useGetDataBooking();
	const client: IClient = useGetDataClient();
	const cards: ICard[] = useGetCards(client);
	const dispatch = useDispatch();
	const router = useRouter();

	useEffect(() => {
		console.log(booking);
		if (booking.client == '' && booking != INITIAL_BOOKING_STATE)
			router.push('/login');
	}, [booking]);

	const submitBooking = async (num: string) => {
		booking.card = parseInt(num);
		const postedBooking: IBookingPost = await postBooking(
			booking,
			client.token!
		);
		if (postedBooking != INITIAL_BOOKING_STATE) {
			dispatch(
				addBooking({
					client: postedBooking.client,
					pickUp: '',
					dropOff: '',
					dateStart: '',
					dateEnd: '',
					group: '',
					card: 0,
				})
			);
			router.push('/home');
		}
	};

	return (
		<>
			<Table>
				<TableHead>
					<TableRow>
						<TableHeaderCell> Fecha de Recogida </TableHeaderCell>
						<TableHeaderCell> Fecha de Entrega </TableHeaderCell>
						<TableHeaderCell> Sucursal Recogida </TableHeaderCell>
						<TableHeaderCell> Sucursal Entrega </TableHeaderCell>
						<TableHeaderCell> Grupo Coche </TableHeaderCell>
					</TableRow>
				</TableHead>

				<TableBody>
					<TableRow>
						<TableCell>{booking.dateStart}</TableCell>
						<TableCell>{booking.dateEnd}</TableCell>
						<TableCell>{booking.pickUp}</TableCell>
						<TableCell>{booking.dropOff}</TableCell>
						<TableCell>{booking.group}</TableCell>
					</TableRow>
				</TableBody>
			</Table>

			<p>
				<strong>Elige tarjeta</strong>
			</p>
			{cards.map((card, index) => (
				<Button
					color="green"
					key={index}
					onClick={(e) => void submitBooking(e.currentTarget.value)}
					value={card.numberCode}
				>
					{card.numberCode}
				</Button>
			))}

			<Button color="yellow">
				<Link href="/profile/add-card">Añadir tarjeta</Link>
			</Button>
		</>
	);
}
