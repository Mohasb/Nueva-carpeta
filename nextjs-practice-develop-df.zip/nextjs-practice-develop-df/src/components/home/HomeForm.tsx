import { useAllBranchData, useGetDataBooking } from '~/hooks/hooks';
import { TODAY_STRING } from '~/utils/constants/constants';
import { useState } from 'react';
import { InputDate, InputSelect } from '~/components/components';
import { useAppDispatch } from '~/hooks/store';
import { addGroups } from '~/store/groups/slice';
import onChecked, {
	createHourList,
	getSevenDaysLater,
	onDayEndChange,
	onDayStartChange,
	onSubmit,
} from '../../../app/home/function';
import { useRouter } from 'next/navigation';
import { IAvailable } from '~/models/available_model';
import { IBookingPost } from '~/models/booking_post_model';
import { Button, Card, Title } from '@tremor/react';

export default function HomeForm() {
	const branches: string[] = useAllBranchData();
	const router = useRouter();

	const [dayStart, setDayStart] = useState(TODAY_STRING);
	const [dayEnd, setDayEnd] = useState(getSevenDaysLater(TODAY_STRING));
	const hourList = createHourList();
	const [check, setCheck] = useState(false);
	const dispatch = useAppDispatch();
	const booking: IBookingPost = useGetDataBooking();
	const [pickUp, setPickUp] = useState<string>('Benidorm');
	const [dropOff, setDropOff] = useState<string>('');
	const [hourStart, setHourStart] = useState<string>('12:00');
	const [hourEnd, setHourEnd] = useState<string>('12:00');

	const submitGroups = async () => {
		const groups: IAvailable[] = await onSubmit(
			pickUp,
			dropOff,
			hourStart,
			hourEnd,
			dayStart,
			dayEnd,
			dispatch,
			booking
		);
		dispatch(addGroups(groups));
		router.push('/groups');
	};

	const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();
		console.log(pickUp);
		console.log(dropOff);
		console.log(hourStart);
		console.log(hourEnd);

		void submitGroups();
	};

	return (
		<Card style={{ margin: '20px', width: '30%' }}>
			<form onSubmit={handleSubmit}>
				<div>
					<Title>HOME</Title>
					<InputSelect
						dataList={branches}
						style={{ margin: '5px', width: '200px' }}
						value={pickUp}
						setValue={setPickUp}
					/>
					{check == true && (
						<InputSelect
							dataList={branches}
							style={{ margin: '5px', width: '200px' }}
							value={dropOff}
							setValue={setDropOff}
						/>
					)}
					<input
						type="checkbox"
						onChange={(event) => {
							onChecked(event, setCheck);
						}}
						style={{ margin: '5px' }}
					/>
				</div>
				<div>
					<InputDate
						style={{ border: '1px solid black', margin: '5px' }}
						value={dayStart}
						placeholder={'Día de recogida'}
						onChange={(event) => {
							onDayStartChange(event, setDayStart, dayEnd, setDayEnd);
						}}
					/>
					<InputDate
						style={{ border: '1px solid black', margin: '5px' }}
						value={dayEnd}
						placeholder={'Día de entrega'}
						onChange={(event) => {
							onDayEndChange(event, dayStart, setDayEnd);
						}}
					/>
				</div>
				<div>
					<InputSelect
						dataList={hourList}
						style={{ margin: '5px', width: '200px' }}
						value={hourStart}
						setValue={setHourStart}
					/>
					<InputSelect
						dataList={hourList}
						style={{ margin: '5px', width: '200px' }}
						value={hourEnd}
						setValue={setHourEnd}
					/>
				</div>

				<div>
					<Button type="submit">ENVIAR</Button>
				</div>
			</form>
		</Card>
	);
}
