import { Button, TextInput } from '@tremor/react';
import { useRouter } from 'next/navigation';
import { useAppDispatch } from '~/hooks/store';
import useGetDataBooking from '~/hooks/useGetDataBooking';
import { IBookingPost } from '~/models/booking_post_model';
import { IClient } from '~/models/client_model';
import { postClientLogin } from '~/services/services';
import { addBooking } from '~/store/booking/slice';
import { login } from '~/store/login/slice';
import { INITIAL_CLIENT_STATE } from '~/utils/constants/constants';

export default function LoginForm() {
	const dispatch = useAppDispatch();
	const booking: IBookingPost = useGetDataBooking();
	const router = useRouter();

	const doLogin = async (dni: string, password: string) => {
		const loggedClient: IClient = await postClientLogin(dni, password);

		if (loggedClient != INITIAL_CLIENT_STATE) {
			dispatch(login(loggedClient));
			dispatch(
				addBooking({
					pickUp: booking.pickUp,
					dropOff: booking.dropOff,
					dateStart: booking.dateStart,
					dateEnd: booking.dateEnd,
					group: booking.group,
					client: loggedClient.dni,
					card: booking.card,
				})
			);

			if (booking.group != '') router.push('/confirm');
			else if (booking.dateStart != '') router.push('/groups');
			else router.push('/home');
		}
	};

	const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();
		const form = event.currentTarget;
		const formData = new FormData(form);

		void doLogin(
			formData.get('dni') as string,
			formData.get('password') as string
		);
	};

	return (
		<>
			<form
				onSubmit={handleSubmit}
				style={{ maxWidth: '200px', margin: '10px' }}
			>
				<TextInput name="dni" type="text" placeholder="DNI" />
				<TextInput name="password" type="password" placeholder="Password" />
				<Button type="submit">Login</Button>
			</form>
		</>
	);
}
