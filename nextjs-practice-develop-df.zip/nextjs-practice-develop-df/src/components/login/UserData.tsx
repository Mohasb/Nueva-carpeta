'use client';

import { useAppDispatch, useAppSelector } from '~/hooks/store';
import { IClient } from '~/models/client_model';
import { login, logout, selectLoginState } from '~/store/login/slice';
import { useEffect, useState } from 'react';
import { Button, Title } from '@tremor/react';

export default function UserData() {
	const loginState = useAppSelector(selectLoginState);
	const dispatch = useAppDispatch();
	const [loading, setLoading] = useState(true);

	useEffect(() => {
		if (loginState.login.id == -1) {
			const persistedState = localStorage.getItem('logged__user');
			if (persistedState != null) {
				const persistedClient: IClient = JSON.parse(persistedState);
				dispatch(login(persistedClient));
			}
		}
		setLoading(false);
	}, []);

	const handleLogout = () => {
		dispatch(logout());
	};

	return (
		<>
			<div className="box">
				<Title>User Data</Title>

				{loading ? (
					<p>Loading...</p>
				) : (
					<>
						{loginState.login.id == -1 ? (
							<p>No user logged</p>
						) : (
							<>
								<p>User logged</p>
								<Button onClick={handleLogout}>Logout</Button>
							</>
						)}
					</>
				)}
			</div>
		</>
	);
}
