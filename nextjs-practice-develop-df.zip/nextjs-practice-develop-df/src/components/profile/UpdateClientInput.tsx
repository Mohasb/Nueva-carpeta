import { TableCell, TableRow, TextInput } from '@tremor/react';
import { IUpdateClientRow } from '~/interfaces/interfaces';

export const UpdateClientRow = ({
	field,
	name,
	defaultValue,
}: IUpdateClientRow) => {
	return (
		<TableRow>
			<TableCell>{field}:</TableCell>
			<TableCell>
				<TextInput
					name={name}
					type="text"
					defaultValue={defaultValue}
					placeholder=""
				/>
			</TableCell>
		</TableRow>
	);
};
