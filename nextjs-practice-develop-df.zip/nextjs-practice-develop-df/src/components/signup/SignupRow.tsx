import { TableCell, TableRow, TextInput } from '@tremor/react';
import { ISignupRow } from '~/interfaces/interfaces';

export const SignupRow = ({ field, name, type }: ISignupRow) => {
	return (
		<TableRow>
			<TableCell>{field}:</TableCell>
			<TableCell>
				<TextInput name={name} type={type} placeholder="" />
			</TableCell>
		</TableRow>
	);
};
