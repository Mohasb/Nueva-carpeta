import { useEffect, useState } from 'react';
import { IBranch } from '~/models/models';
import { getAllBranches } from '~/services/services';

export default function useAllBranchData(): string[] {
	const [branch, setBranch] = useState<string[]>([]);

	useEffect(() => {
		async function getData() {
			const res = await getAllBranches();
			const resultado: string[] = res.map((element: IBranch) => element.name);
			setBranch(resultado);
		}

		void getData();
	}, []);

	return branch;
}
