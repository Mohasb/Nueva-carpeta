import { IClient } from '~/models/models';
import { getCardsByClient } from '~/services/services';

export default function useAllCardsByClientData() {
	async function getCards(client: IClient) {
		return getCardsByClient(client.dni, client.token!);
	}

	return { getCards };
}
