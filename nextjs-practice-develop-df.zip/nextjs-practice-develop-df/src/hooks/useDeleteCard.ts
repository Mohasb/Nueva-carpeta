import { IP } from '~/utils/constants/constants';

export default function useDeleteCard(
	id: number | string,
	token: string | undefined
) {
	fetch(`${IP}/Card/${id}`, {
		method: 'DELETE',
		headers: {
			// eslint-disable-next-line @typescript-eslint/restrict-template-expressions
			Authorization: `Bearer ${token}`,
		},
	})
		.then((response) => {
			if (response.status != 200) throw new Error();
			return response.json();
		})
		.catch(() => []);
}
