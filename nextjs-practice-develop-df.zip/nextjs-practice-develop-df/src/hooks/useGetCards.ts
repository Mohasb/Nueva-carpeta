import { ICard, IClient } from '~/models/models';
import { useEffect, useState } from 'react';
import { INITIAL_CLIENT_STATE } from '~/utils/constants/constants';
import { useAllCardsByClientData } from './hooks';

export default function useGetCards(client: IClient): ICard[] {
	const { getCards } = useAllCardsByClientData();
	const [cards, setCards] = useState<ICard[]>([]);
	useEffect(() => {
		async function setCardsValue() {
			setCards(await getCards(client));
		}

		if (client != INITIAL_CLIENT_STATE) void setCardsValue();
	}, [client]);

	return cards;
}
