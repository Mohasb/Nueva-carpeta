import { useEffect, useState } from 'react';
import { IBookingPost } from '~/models/booking_post_model';
import { INITIAL_BOOKING_STATE } from '~/utils/constants/constants';

export default function useGetDataBooking() {
	const [booking, setBooking] = useState<IBookingPost>(INITIAL_BOOKING_STATE);
	useEffect(() => {
		function cambiarValor() {
			const data = window.localStorage.getItem('_booking');

			if (data != null) {
				const bookingValue = JSON.parse(data) as IBookingPost;
				setBooking(bookingValue);
			}
		}

		void cambiarValor();
	}, []);

	return booking;
}
