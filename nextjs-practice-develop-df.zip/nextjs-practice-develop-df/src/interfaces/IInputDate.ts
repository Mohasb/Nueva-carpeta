import { CSSProperties, ChangeEventHandler } from 'react';

export interface IInputDate {
	value: string;
	placeholder: string;
	onChange: ChangeEventHandler<HTMLInputElement>;
	style?: CSSProperties | undefined;
}
