import { CSSProperties } from 'react';

export interface IInputSelect {
	style?: CSSProperties | undefined;
	dataList: string[];
	value: string;
	setValue: (value: string) => void;
}
