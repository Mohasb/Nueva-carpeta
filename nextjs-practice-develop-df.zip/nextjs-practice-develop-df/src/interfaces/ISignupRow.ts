export interface ISignupRow {
	field: string;
	name: string;
	type: 'text' | 'password' | undefined;
}
