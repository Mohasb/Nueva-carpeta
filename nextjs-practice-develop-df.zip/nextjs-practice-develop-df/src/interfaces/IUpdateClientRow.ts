export interface IUpdateClientRow {
	field: string;
	name: string;
	defaultValue: string;
}
