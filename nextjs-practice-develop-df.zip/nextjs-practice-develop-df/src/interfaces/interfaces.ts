import { IInputSelect } from './IInputSelect';
import { IInputDate } from './IInputDate';
import { ISignupRow } from './ISignupRow';
import { IUpdateClientRow } from './IUpdateClientRow';

export type { IInputSelect, IInputDate, ISignupRow, IUpdateClientRow };
