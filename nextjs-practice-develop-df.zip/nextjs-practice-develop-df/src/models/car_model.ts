export interface ICar {
	id: number;
	model: string;
	automatic: boolean;
	licensePlate: string;
	doors: number;
	seats: number;
	gasType: string;
	suitcases: number;
	dayPrice: number;
	groupId: number;
	branchId: number;
}
