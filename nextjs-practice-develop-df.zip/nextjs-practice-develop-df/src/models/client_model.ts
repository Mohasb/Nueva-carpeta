export interface IClient {
	id?: number;
	dni: string;
	name: string;
	surname: string;
	age: number;
	email: string;
	password: string;
	phone: number;
	address: string;
	cp: number;
	city: string;
	country: string;
	token?: string;
}
