export interface IGroup {
	id: number;
	name: string;
	photo: string;
}
