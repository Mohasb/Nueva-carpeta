export interface IPlanning {
	dayHour: Date;
	branch: string;
	group: string;
	available: number;
}
