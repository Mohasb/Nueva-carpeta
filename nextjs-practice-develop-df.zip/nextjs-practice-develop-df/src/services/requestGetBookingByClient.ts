import { IBooking } from '~/models/booking_model';
import { IP } from '~/utils/constants/constants';

export async function getBookingByClient(
	client: string,
	token: string
): Promise<IBooking[]> {
	return fetch(`${IP}/Booking/clientBookings/${client}`, {
		headers: {
			Authorization: `Bearer ${token}`,
		},
	})
		.then((response) => {
			if (response.status != 200) throw new Error();
			return response.json();
		})
		.then((res: IBooking[]) => res)
		.catch(() => []);
}
