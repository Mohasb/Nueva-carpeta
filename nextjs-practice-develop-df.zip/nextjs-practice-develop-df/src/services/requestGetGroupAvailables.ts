import { IAvailable } from '~/models/models';
import { IP } from '~/utils/constants/constants';

export async function getAllGroupsAvailable(
	PickUp: string,
	DateStart: string,
	DateEnd: string
): Promise<IAvailable[]> {
	return fetch(`${IP}/Booking/${PickUp}&${DateStart}&${DateEnd}`, {
		method: 'GET',
	})
		.then(async (response) => {
			if (response.status != 200) throw new Error();
			return response.json();
		})
		.then((res: IAvailable[]) => res)
		.catch(() => []);
}
