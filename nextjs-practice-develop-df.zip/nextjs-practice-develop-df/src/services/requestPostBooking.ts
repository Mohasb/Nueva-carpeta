import { IBookingPost } from '~/models/booking_post_model';
import { INITIAL_BOOKING_STATE, IP } from '~/utils/constants/constants';

export async function postBooking(
	booking: IBookingPost,
	token: string
): Promise<IBookingPost> {
	return fetch(`${IP}/Booking`, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
			Authorization: `Bearer ${token}`,
		},
		body: JSON.stringify(booking),
	})
		.then((response) => {
			if (response.status != 201) throw new Error();
			return response.json();
		})
		.then((res: IBookingPost) => res)
		.catch(() => INITIAL_BOOKING_STATE);
}
