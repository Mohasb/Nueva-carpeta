import { PayloadAction, createSlice } from '@reduxjs/toolkit';
import { IBookingPost } from '~/models/models';
import { RootState } from '..';
import { INITIAL_BOOKING_STATE } from '~/utils/constants/constants';

export const bookingSlice = createSlice({
	name: 'booking',
	initialState: INITIAL_BOOKING_STATE,
	reducers: {
		addBooking: (state, action: PayloadAction<IBookingPost>) => {
			localStorage.setItem(
				'_booking',
				JSON.stringify({ ...state, ...action.payload })
			);
			return { ...state, ...action.payload };
		},
	},
});

export const selectBookingState = (state: RootState) => state;
export const { addBooking } = bookingSlice.actions;

export default bookingSlice.reducer;
