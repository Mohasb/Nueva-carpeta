import { PayloadAction, createSlice } from '@reduxjs/toolkit';
import { RootState } from '..';
import { IAvailable } from '~/models/available_model';
import { INITIAL_AVAILABLE_STATE } from '~/utils/constants/constants';

export const groupSlice = createSlice({
	name: 'groups',
	initialState: INITIAL_AVAILABLE_STATE,
	reducers: {
		addGroups: (state, action: PayloadAction<IAvailable[]>) => {
			localStorage.setItem('_groups', JSON.stringify(action.payload));
			return { ...action.payload };
		},
	},
});

export const selectGroupState = (state: RootState) => state;
export const { addGroups } = groupSlice.actions;

export default groupSlice.reducer;
