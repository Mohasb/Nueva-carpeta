'use client';

import { Provider } from 'react-redux';
import ConfirmContent from '~/components/confirm/ConfirmContent';
import { store } from '~/store';

export default function Confirm() {
	return (
		<>
			<Provider store={store}>
				<ConfirmContent />
			</Provider>
		</>
	);
}
