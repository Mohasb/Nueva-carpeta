'use client';
import { Provider } from 'react-redux';
import GroupContent from '~/components/groups/GroupContent';
import { store } from '~/store';

export default function Groups() {
	return (
		<>
			<Provider store={store}>
				<GroupContent />
			</Provider>
		</>
	);
}
