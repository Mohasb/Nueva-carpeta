'use client';

import UserData from '~/components/login/UserData';
import { Provider } from 'react-redux';
import { store } from '~/store';
import LoginForm from '~/components/login/LoginForm';

export default function Login() {
	return (
		<>
			<h1>Login</h1>

			<Provider store={store}>
				<UserData />
				<LoginForm />
			</Provider>
		</>
	);
}
