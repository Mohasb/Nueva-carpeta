'use client';
import { useRouter } from 'next/navigation';
import useGetDataBooking from '~/hooks/useGetDataBooking';
import useGetDataClient from '~/hooks/useGetDataClient';
import { IBookingPost } from '~/models/booking_post_model';
import { ICard } from '~/models/card_model';
import { IClient } from '~/models/client_model';
import { postCard } from '~/services/services';
import {
	INITIAL_BOOKING_STATE,
	INITIAL_CARD_STATE,
} from '~/utils/constants/constants';

export default function Page() {
	const router = useRouter();
	const client: IClient = useGetDataClient();
	const booking: IBookingPost = useGetDataBooking();

	async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
		e.preventDefault();
		const form = e.currentTarget;
		const formData = new FormData(form);

		const card: ICard = {
			numberCode: formData.get('numberCode') as unknown as number,
			expirationDate: formData.get('expirationDate') as unknown as Date,
			ownerName: client.name + ' ' + client.surname,
			client: client.dni,
		};

		const postedCard = await postCard(card);
		if (postedCard == INITIAL_CARD_STATE) router.push('/login');
		else if (booking != INITIAL_BOOKING_STATE && booking.group != '')
			router.push('/confirm');
		else router.push('/profile/data');
	}
	return (
		// eslint-disable-next-line @typescript-eslint/no-misused-promises
		<form onSubmit={handleSubmit}>
			<h1>Añadir una tarjeta:</h1>
			<label>Número de tarjeta: </label>
			<input name="numberCode" type="number" />
			<br />
			<label>Fecha de expiración: </label>
			<input name="expirationDate" type="date" />
			<br />
			<input type="submit" value="Añadir" />
		</form>
	);
}
