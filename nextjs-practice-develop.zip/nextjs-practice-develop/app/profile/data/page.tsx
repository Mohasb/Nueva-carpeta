'use client';

import { IClient } from '~/models/client_model';
import Link from 'next/link';
import useGetDataClient from '~/hooks/useGetDataClient';
import { ICard } from '~/models/card_model';
import useGetCards from '~/hooks/useGetCards';

export default function Page() {
	const client: IClient = useGetDataClient();
	const cards: ICard[] = useGetCards(client);

	const cardsHtml = cards.map((card) => {
		const expiration = new Date(card.expirationDate).toLocaleDateString();
		return (
			<li key={card.id}>
				<div>Número de tarjeta: {card.numberCode}</div>
				<div>Titular: {card.ownerName}</div>
				<div>Fecha de caducidad: {expiration}</div>
				<br></br>
			</li>
		);
	});

	if (client) {
		return (
			<div>
				<h1>
					{client.name} {client.surname} - {client.dni}
				</h1>
				<div>Edad: {client.age}</div>
				<br></br>
				<div>Dirección: {client.address}</div>
				<div>
					{client.city}, {client.country} ({client.cp})
				</div>
				<br></br>
				<div>Teléfono: {client.phone}</div>
				<div>Email: {client.email}</div>
				<br></br>
				<label>Tarjetas:</label>
				<ul>{cardsHtml.length ? cardsHtml : 'No tienes tarjetas'}</ul>
				<br />
				<button>
					<Link href="/profile/add-card">Añadir tarjeta</Link>
				</button>
				<br></br>
				<button>
					<Link href="/profile/data/update">Editar mis datos personales</Link>
				</button>
			</div>
		);
	}
}
