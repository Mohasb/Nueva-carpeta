'use client';

import { useRouter } from 'next/navigation';
import { useDispatch } from 'react-redux';
import useGetDataClient from '~/hooks/useGetDataClient';
import { IClient } from '~/models/client_model';
import { updateClient } from '~/services/requestUpdateClient';
import { login } from '~/store/login/slice';
import { INITIAL_CLIENT_STATE } from '~/utils/constants/constants';

export default function Page() {
	const dispatch = useDispatch();
	const client: IClient = useGetDataClient();
	const router = useRouter();

	async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
		e.preventDefault();
		const form = e.currentTarget;
		const formData = new FormData(form);
		const uClient: IClient = {
			dni: formData.get('dni') as string,
			name: formData.get('name') as string,
			surname: formData.get('surname') as string,
			age: formData.get('age') as unknown as number,
			email: formData.get('email') as string,
			password: formData.get('password') as string,
			phone: formData.get('phone') as unknown as number,
			address: formData.get('address') as string,
			cp: formData.get('cp') as unknown as number,
			city: formData.get('city') as string,
			country: formData.get('country') as string,
		};

		const updatedClient: IClient = await updateClient(uClient);

		if (updatedClient == INITIAL_CLIENT_STATE) router.push('/login');

		updatedClient.token = client.token;
		dispatch(login(updatedClient));
		router.push('/profile/data');
	}

	if (client) {
		return (
			// eslint-disable-next-line @typescript-eslint/no-misused-promises
			<form onSubmit={handleSubmit}>
				<h1>Editar datos personales:</h1>
				<label>Nombre: </label>
				<input name="name" type="text" defaultValue={client.name} />
				<br />
				<label>Apellidos: </label>
				<input name="surname" type="text" defaultValue={client.surname} />
				<br />
				<label>DNI: </label>
				<input name="dni" type="text" defaultValue={client.dni} />
				<br />
				<label>Edad: </label>
				<input name="age" type="number" defaultValue={client.age} />
				<br />
				<label>Dirección: </label>
				<input name="address" type="text" defaultValue={client.address} />
				<br />
				<label>Ciudad: </label>
				<input name="city" type="text" defaultValue={client.city} />
				<br />
				<label>País: </label>
				<input name="country" type="text" defaultValue={client.country} />
				<br />
				<label>Código postal: </label>
				<input name="cp" type="number" defaultValue={client.cp} />
				<br />
				<label>Teléfono: </label>
				<input name="phone" type="number" defaultValue={client.phone} />
				<br />
				<label>Email: </label>
				<input name="email" type="email" defaultValue={client.email} />
				<br />
				<label>Contraseña: </label>
				<input name="password" type="password" />
				<br />
				<input type="submit" defaultValue="Editar" />
			</form>
		);
	}
}
