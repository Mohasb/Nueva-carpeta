'use client';

import { IClient } from '~/models/client_model';
import { useState } from 'react';
import useGetDataClient from '~/hooks/useGetDataClient';
import useGetBooking from '~/hooks/useGetBooking';

export default function Page() {
	const client: IClient = useGetDataClient();
	const [loading, setLoading] = useState(true);
	const bookings = useGetBooking(client, setLoading);

	const bookingsHtml = bookings.map((booking) => {
		return (
			<tbody key={booking.id}>
				<tr>
					<th scope="row">{booking.id}</th>
					<td>{booking.dateStart.toString()}</td>
					<td>{booking.dateEnd.toString()}</td>
					<td>{booking.pickUp}</td>
					<td>{booking.dropOff}</td>
					<td>{booking.licensePlate}</td>
					{/* <td>{booking.status}</td> */}
				</tr>
			</tbody>
		);
	});

	return (
		<>
			<div>
				<h1>Bienvenido, {client && client.name}</h1>
				{loading ? (
					<p>Loading...</p>
				) : (
					<>
						{bookings.length == 0 ? (
							<h2>Todavía no tienes reservas</h2>
						) : (
							<>
								<h2>Tus reservas:</h2>
								<table>
									<thead>
										<tr>
											<th scope="col">#</th>
											<th scope="col">Fecha inicial</th>
											<th scope="col">Fecha final</th>
											<th scope="col">Sucursal de recogida</th>
											<th scope="col">Sucursal de devolución</th>
											<th scope="col">Matrícula</th>
											{/* <th scope="col">Estado</th> */}
										</tr>
									</thead>
									{bookingsHtml}
								</table>
							</>
						)}
					</>
				)}
			</div>
		</>
	);
}
