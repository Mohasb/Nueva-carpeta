'use client';

import { useRouter } from 'next/navigation';
import { useDispatch } from 'react-redux';
import { IClient } from '~/models/client_model';
import { postClientRegister } from '~/services/requestPostClientRegister';
import { login } from '~/store/login/slice';
import { INITIAL_CLIENT_STATE } from '~/utils/constants/constants';

export default function Page() {
	const dispatch = useDispatch();
	const router = useRouter();

	async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
		e.preventDefault();

		const form = e.currentTarget;
		const formData = new FormData(form);

		const client: IClient = {
			dni: formData.get('dni') as string,
			name: formData.get('name') as string,
			surname: formData.get('surname') as string,
			age: formData.get('age') as unknown as number,
			email: formData.get('email') as string,
			password: formData.get('password') as string,
			phone: formData.get('phone') as unknown as number,
			address: formData.get('address') as string,
			cp: formData.get('cp') as unknown as number,
			city: formData.get('city') as string,
			country: formData.get('country') as string,
		};

		if (
			client.name == '' ||
			client.surname == '' ||
			client.dni == '' ||
			formData.get('age') == '' ||
			client.email == '' ||
			client.password == '' ||
			formData.get('passwordCheck') == '' ||
			formData.get('phone') == '' ||
			client.address == '' ||
			formData.get('cp') == '' ||
			client.city == '' ||
			client.country == ''
		)
			return alert('Has de rellenar todos los campos');

		if (formData.get('password') != formData.get('passwordCheck'))
			return alert('Contraseñas distintas');

		const createdClient = await postClientRegister(client);

		if (createdClient != INITIAL_CLIENT_STATE) {
			dispatch(login(createdClient));
			router.push('/');
		}
	}

	return (
		<div>
			<h1>Registro</h1>
			{/* eslint-disable-next-line @typescript-eslint/no-misused-promises */}
			<form onSubmit={handleSubmit}>
				<label>Nombre: </label>
				<input type="text" name="name"></input>
				<br></br>
				<label>Apellidos: </label>
				<input type="text" name="surname"></input>
				<br></br>
				<label>Edad: </label>
				<input type="number" name="age"></input>
				<br></br>
				<label>DNI: </label>
				<input type="text" name="dni"></input>
				<br></br>
				<label>Email: </label>
				<input type="email" name="email"></input>
				<br></br>
				<label>Teléfono: </label>
				<input type="number" name="phone"></input>
				<br></br>
				<label>Dirección: </label>
				<input type="text" name="address"></input>
				<br></br>
				<label>País: </label>
				<input type="text" name="country"></input>
				<br></br>
				<label>Ciudad: </label>
				<input type="text" name="city"></input>
				<br></br>
				<label>Código postal: </label>
				<input type="number" name="cp"></input>
				<br></br>
				<label>Contraseña: </label>
				<input type="password" name="password"></input>
				<br></br>
				<label>Repite contraseña: </label>
				<input type="password" name="passwordCheck"></input>
				<br></br>
				<input type="submit" value="Enviar"></input>
			</form>
		</div>
	);
}
