## Contenido que nos falta por incluir

 - Los coches disponibles que se muestren son tarjetas del coche destacado. Se podrá pulsar y mostrará o no los datos detallados del mismo.
 - En la primera parte de la reserva, habrá que incluir la selección de la edad.
 - Cuando no haya ningún grupo disponible se mostrará un mensaje.
 - Ordenar los coches destacados por precio.
 - Un listado de servicios para la reserva.
 - En la finalización de la reserva: Seleccionar método de pago, descuentos, check de aceptar condiciones de reserva y alquiler.
 - Redirección de realizar reserva al área de clientes.
 - Mejorar listado de reservas (reservas activas - pasadas -> ver detalles al pulsar)
 - Cancelar reservas que aún no han ocurrido.
 - Capar el nº de tarjeta.
 - Poder eliminar una tarjeta y mostrar un botón de confirmación. Al borrar, saltará un mensaje de confirmación.
 - Los coches  se mostrarán en columnas de 3.
 - Incluir filtro en la lista de coches a partir del nº de plazas, el tipo de combustible y el tipo de cambio.
 - El filtro será si hay más de 10 coches.
 - Crear el layout determinado en el [General layout](./doc/general-layout.md)