# Booking process

El proceso de reserva inicia en la home con el formulario de disponibilidad.

## Paso 1: Formulario de disponibilidad

El formulario de disponibilidad tendrá los siguientes campos:

- Oficina de recogida.
- Oficina de devolución.
- Fecha de recogida.
- Hora de recogida.
- Fecha de devolución.
- Hora de devolución.
- Opción de elegir otra oficina de devolución.
- Edad del conductor. Tendrá tres opciones: 18-24, 25-69 y 70 o más.
- Botón de buscar.

### Validaciones

- Por defect solo mostraremos la sucursal de recogida, si marca la opción de elegir otra sucursal de devolución, mostraremos la sucursal de devolución.
- Si la sucursal de recogida cambia, se establece este mismo valor en la sucursal de devolución.
- La fecha de recogida no puede ser anterior a la fecha actual (Valor por defecto fecha actual).
- La fecha de devolución no puede ser anterior a la fecha de recogida (Valor por defecto fecha de recogida + 7 días).
- Si cambia la fecha de recogida, se establece el valor fecha de recogida + 7 días en la fecha de devolución (si el valor de la fecha de devolución es menor que la fecha de recogida).
- Para poder buscar debe rellenar todos los campos

### Resultados de búsqueda

Si hay resultados de coches disponibles para reserva, se mostrará el listado de coches con la información de cada coche. Si no hay resultados, se mostrará un mensaje indicando que no hay coches disponibles para la búsqueda realizada.

## Paso 2: listado de coches

En el listado de coches se mostrará la siguiente información:

- Imagen del coche
- Marca y modelo del coche
- características (Tipo de cambio, número de plazas, tipo de combustible, número de puertas, cupo para maletas)
- Precio total
- Botón de reserva

> Se ordena la lista por precio de forma ascendente y utilizaremos el mismo filtro que se utiliza en el listado de coches.

## Paso 3: Listado de servicios adicionales

Mostraremos el listado de servicios adicionales. El listado de servicios adicionales tendrá la siguiente información:

- Imagen del servicio
- Nombre, descripción
- Precio
- Botón de añadir

## Paso 4: Resumen de reserva

Solo mostraremos este paso, si el cliente está identificado. SI no está identificado mostraremos un formulario de login/registro.

Una vez identificado el cliente mostraremos el resumen de la reserva. El resumen de la reserva tendrá la siguiente información:

- Información del coche: Imagen, marca, modelo y precio
- Información de la reserva: Oficina de recogida, oficina de devolución, fecha de recogida, fecha de devolución, precio total
- Listado de servicios adicionales: nombre y precio
- Si tine un código de descuento, se mostrará el descuento aplicado
- Total de la reserva
- Opciones de pago (Solo tendrá opción de pago con tarjeta y en la oficina)
- Check para aceptar las condiciones de la reserva y alquiler
- Botón de confirmar reserva

> al registrar la reserva se redirige al detalle de la reserva en su área de clientes.
