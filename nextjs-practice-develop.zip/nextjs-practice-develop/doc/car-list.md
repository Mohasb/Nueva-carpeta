# Car list

Mostraremos un listado de coches de 3 columnas. Cada coche tendrá la siguiente información:

- Imagen del coche.
- Marca y modelo del coche.
- Tipo de cambio
- Número de plaza.
- Tipo de combustible
- Número de puertas
- Cupo para maletas
- Botón de reserva. Al pulsar en reservar iremos a la página de reserva del coche. y en el listado de coches solo mostraremos el seleccionado

## Filtro de coches

En la parte superior del listado de coches, mostraremos un filtro de coches. El filtro de coches tendrá los siguientes campos:

- Número de plazas
- Tipo de combustible
- Tipo de cambio

> El filtro de coches solo se mostrará si hay más de 10 coche en la lista.
