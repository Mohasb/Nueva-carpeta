# Customer Area

El área de cliente es la zona privada de los clientes conectados como usuarios. En el área de cliente tendrá las siguiente funcionalidades:

- Ver y editar sus datos personales.
- Ver sus reservas.
- Ver sus tarjetas de crédito vinculadas.

> Toda el área de cliente es privada, nadie puede acceder a una de estas secciones sin antes hace login

## Listado de reserva

Mostrará un listado de las reservas activas y pasadas del cliente. En el listado, cada reserva tendrá la siguiente información:

- Estado de la reserva.
- Fecha de inicio y fin.
- Oficina de recogida y devolución.
- Coche reservado.

## Detalle de una reserva

Al pulsar sobre una reserva del listado, se mostrará el detalle de la reserva. En el detalle de la reserva se mostrará la siguiente información:

- Estado de la reserva.
- Fecha de inicio y fin.
- Oficina de recogida y devolución.
- Coche reservado.
- Precio total de la reserva.
- Desglose del importe de la reserva.
- Botón para cancelar la reserva.

> Un cliente solo puede acceder a sus reservas. Si intenta acceder a una reserva que no es suya, la API deberá retornar un error y en cliente enviarlo al listado de reservas.

### Cancelar una reserva

Al pulsar sobre el botón de cancelar una reserva, se mostrará un modal de confirmación. Si el usuario confirma la cancelación, se cancelará la reserva y se mostrará un mensaje de confirmación.

> El botón de cancelar solo se mostrará si la reserva está activa pero no está en curso.

## Listado de tarjetas de crédito

Mostrará un listado de las tarjetas de crédito vinculadas al cliente. En el listado, cada tarjeta tendrá la siguiente información:

- Últimos 4 dígitos de la tarjeta.
- Fecha de caducidad de la tarjeta.
- Nombre del titular de la tarjeta.

> En el listado no mostraremos el número completo de la tarjeta por motivos de seguridad. Lo mostraremos con este formato 1111 **\*\*\*** 9999.

### Añadir una tarjeta de crédito

Al pulsar sobre el botón de añadir una tarjeta de crédito, se mostrará un formulario para añadir una tarjeta de crédito. El formulario tendrá los siguientes campos:

- Número de tarjeta.
- Fecha de caducidad de la tarjeta.
- Nombre del titular de la tarjeta.
- Botón para añadir la tarjeta.

### Eliminar una tarjeta de crédito

Al pulsar sobre el botón de eliminar una tarjeta de crédito, se mostrará un modal de confirmación. Si el usuario confirma la eliminación, se eliminará la tarjeta y se mostrará un mensaje de confirmación.

## Editar datos personales

Al pulsar sobre el botón de editar datos personales, se mostrará un formulario para editar los datos personales del cliente. El formulario tendrá los siguientes campos:

- Nombre.
- Apellidos.
- Email.
- Teléfono.
- Dirección.
- Código postal.
- Ciudad.
- País.

> Utilizar aquí los datos que habéis utilizado en vuestra base de datos para un cliente

- Botón para guardar los cambios.
