import { IInputSelect } from '~/interfaces/interfaces';

export default function InputSelect({ style, value, dataList }: IInputSelect) {
	return (
		<>
			<select style={style} name={value} id={value} defaultValue={'12:00'}>
				{dataList.map((element, index) => (
					<option key={index}>{element}</option>
				))}
			</select>
		</>
	);
}
