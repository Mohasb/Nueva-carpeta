import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useGetCards, useGetDataClient } from '~/hooks/hooks';
import useGetDataBooking from '~/hooks/useGetDataBooking';
import { IBookingPost } from '~/models/booking_post_model';
import { ICard, IClient } from '~/models/models';
import { postBooking } from '~/services/services';
import { addBooking } from '~/store/booking/slice';
import { INITIAL_BOOKING_STATE } from '~/utils/constants/constants';

export default function ConfirmContent() {
	const booking: IBookingPost = useGetDataBooking();
	const client: IClient = useGetDataClient();
	const cards: ICard[] = useGetCards(client);
	const dispatch = useDispatch();
	const router = useRouter();

	useEffect(() => {
		console.log(booking);
		if (booking.client == '' && booking != INITIAL_BOOKING_STATE)
			router.push('/login');
	}, [booking]);

	const submitBooking = async (num: string) => {
		booking.card = parseInt(num);
		const postedBooking: IBookingPost = await postBooking(
			booking,
			client.token!
		);
		if (postedBooking != INITIAL_BOOKING_STATE) {
			dispatch(
				addBooking({
					client: postedBooking.client,
					pickUp: '',
					dropOff: '',
					dateStart: '',
					dateEnd: '',
					group: '',
					card: 0,
				})
			);
			router.push('/');
		}
	};

	return (
		<>
			<table>
				<thead>
					<tr>
						<td>Fecha de Recogida</td>
						<td>Fecha de Entrega</td>
						<td>Sucursal Recogida</td>
						<td>Sucursal Entrega</td>
						<td>Grupo Coche</td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>{booking.dateStart}</td>
						<td>{booking.dateEnd}</td>
						<td>{booking.pickUp}</td>
						<td>{booking.dropOff}</td>
						<td>{booking.group}</td>
					</tr>
				</tbody>
			</table>

			<div>Elige tarjeta</div>
			{Object.values(cards).map((card, index) => (
				<button
					key={index}
					onClick={(e) => void submitBooking(e.currentTarget.value)}
					value={card.numberCode}
				>
					{card.numberCode}
				</button>
			))}

			<button>
				<Link href="/profile/add-card">Añadir tarjeta</Link>
			</button>
		</>
	);
}
