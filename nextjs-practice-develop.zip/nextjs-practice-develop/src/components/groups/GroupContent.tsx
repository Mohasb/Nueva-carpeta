import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useAppSelector } from '~/hooks/store';
import useGetDataBooking from '~/hooks/useGetDataBooking';
import { IBookingPost } from '~/models/booking_post_model';
import { addBooking } from '~/store/booking/slice';
import { selectGroupState } from '~/store/groups/slice';

export default function GroupContent() {
	const groups = useAppSelector(selectGroupState).groups;
	const dispatch = useDispatch();
	const router = useRouter();
	const savedBooking: IBookingPost = useGetDataBooking();

	useEffect(() => {
		console.log('grupos');
	}, []);

	const onClick: React.MouseEventHandler<HTMLButtonElement> = (event) => {
		const group = event.currentTarget.value;
		savedBooking.group = group;
		dispatch(addBooking(savedBooking));
		router.push('/confirm');
	};

	return (
		<>
			<div>
				<h1>Lista Grupos</h1>

				{Object.values(groups).map((group, index) => (
					<button key={index} onClick={onClick} value={group.group}>
						{group.group}
					</button>
				))}
			</div>
		</>
	);
}
