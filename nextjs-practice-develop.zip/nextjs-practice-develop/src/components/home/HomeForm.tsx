import { useAllBranchData, useGetDataBooking } from '~/hooks/hooks';
import {
	ID_DROPOFF,
	ID_HOUREND,
	ID_HOURSTART,
	ID_PICKUP,
	TODAY_STRING,
} from '~/utils/constants/constants';
import { useState } from 'react';
import { InputDate, InputSelect } from '~/components/components';
import { useAppDispatch } from '~/hooks/store';
import { addGroups } from '~/store/groups/slice';
import onChecked, {
	createHourList,
	getSevenDaysLater,
	onDayEndChange,
	onDayStartChange,
	onSubmit,
} from '../../../app/function';
import { useRouter } from 'next/navigation';
import { IAvailable } from '~/models/available_model';
import { IBookingPost } from '~/models/booking_post_model';

export default function HomeForm() {
	const branches: string[] = useAllBranchData();
	const router = useRouter();

	const [dayStart, setDayStart] = useState(TODAY_STRING);
	const [dayEnd, setDayEnd] = useState(getSevenDaysLater(TODAY_STRING));
	const hourList = createHourList();
	const [check, setCheck] = useState(false);
	const dispatch = useAppDispatch();
	const booking: IBookingPost = useGetDataBooking();

	const submitGroups = async () => {
		const groups: IAvailable[] = await onSubmit(
			check,
			dayStart,
			dayEnd,
			dispatch,
			booking
		);
		dispatch(addGroups(groups));
		router.push('/groups');
	};

	const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();
		void submitGroups();
	};

	return (
		<form onSubmit={handleSubmit}>
			<div>
				<h1>HOME</h1>
				<InputSelect value={ID_PICKUP} dataList={branches} />
				{check == true && (
					<InputSelect value={ID_DROPOFF} dataList={branches} />
				)}
			</div>
			<input
				type="checkbox"
				onChange={(event) => {
					onChecked(event, setCheck);
				}}
			/>
			<div>
				<InputDate
					value={dayStart}
					placeholder={'Día de recogida'}
					onChange={(event) => {
						onDayStartChange(event, setDayStart, dayEnd, setDayEnd);
					}}
				/>
				<InputDate
					value={dayEnd}
					placeholder={'Día de entrega'}
					onChange={(event) => {
						onDayEndChange(event, dayStart, setDayEnd);
					}}
				/>
			</div>
			<div>
				<InputSelect value={ID_HOURSTART} dataList={hourList} />
				<InputSelect value={ID_HOUREND} dataList={hourList} />
			</div>

			<div>
				<button>ENVIAR</button>
			</div>
		</form>
	);
}
