import { useRouter } from 'next/navigation';
import { useAppDispatch } from '~/hooks/store';
import useGetDataBooking from '~/hooks/useGetDataBooking';
import { IBookingPost } from '~/models/booking_post_model';
import { IClient } from '~/models/client_model';
import { postClientLogin } from '~/services/services';
import { addBooking } from '~/store/booking/slice';
import { login } from '~/store/login/slice';
import { INITIAL_CLIENT_STATE } from '~/utils/constants/constants';

export default function LoginForm() {
	const dispatch = useAppDispatch();
	const booking: IBookingPost = useGetDataBooking();
	const router = useRouter();

	const doLogin = async (dni: string, password: string) => {
		const loggedClient: IClient = await postClientLogin(dni, password);

		if (loggedClient != INITIAL_CLIENT_STATE) {
			dispatch(login(loggedClient));
			dispatch(
				addBooking({
					pickUp: booking.pickUp,
					dropOff: booking.dropOff,
					dateStart: booking.dateStart,
					dateEnd: booking.dateEnd,
					group: booking.group,
					client: loggedClient.dni,
					card: booking.card,
				})
			);

			if (booking.group != '') router.push('/confirm');
			else if (booking.dateStart != '') router.push('/groups');
			else router.push('/');
		}
	};

	const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();
		const form = event.currentTarget;
		const formData = new FormData(form);

		void doLogin(
			formData.get('dni') as string,
			formData.get('password') as string
		);
	};

	return (
		<>
			<form onSubmit={handleSubmit}>
				DNI <br />
				<input name="dni" type="text" />
				<br />
				Password
				<br />
				<input name="password" type="password" />
				<br />
				<button type="submit">Login</button>
			</form>
		</>
	);
}
