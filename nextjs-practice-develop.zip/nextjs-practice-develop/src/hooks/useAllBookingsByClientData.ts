import { IClient } from '~/models/models';
import { getBookingByClient } from '~/services/services';

export default function useAllBookingsByClientData() {
	async function getBookings(client: IClient) {
		return getBookingByClient(client.dni, client.token!);
	}

	return { getBookings };
}
