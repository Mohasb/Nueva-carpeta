import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { IBooking, IClient } from '~/models/models';
import { INITIAL_CLIENT_STATE } from '~/utils/constants/constants';
import { useAllBookingsByClientData } from './hooks';

export default function useGetBooking(
	client: IClient,
	setLoading: Dispatch<SetStateAction<boolean>>
) {
	const { getBookings } = useAllBookingsByClientData();
	const [bookings, setBookings] = useState<IBooking[]>([]);
	useEffect(() => {
		async function setBookingValue() {
			setBookings(await getBookings(client));
			setLoading(false);
		}

		if (client != INITIAL_CLIENT_STATE) void setBookingValue();
	}, [client]);

	return bookings;
}
