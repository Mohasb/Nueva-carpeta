import { useEffect, useState } from 'react';
import { IClient } from '~/models/models';
import { INITIAL_CLIENT_STATE } from '~/utils/constants/constants';

export default function useGetDataClient() {
	const [client, setClient] = useState<IClient>(INITIAL_CLIENT_STATE);
	useEffect(() => {
		const data = window.localStorage.getItem('logged__user');

		if (data != null) {
			const clientValue = JSON.parse(data) as IClient;
			setClient(clientValue);
		}
	}, []);

	return client;
}
