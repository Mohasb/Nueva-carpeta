import { IInputSelect } from './IInputSelect';
import { IInputDate } from './IInputDate';

export type { IInputSelect, IInputDate };
