export interface IBooking {
	id: number;
	pickUp: string;
	dropOff: string;
	dateStart: Date;
	hourStart: string;
	dateEnd: Date;
	hourEnd: string;
	groupId: number;
	licensePlate: string;
	clientId: number;
	card: number;
}
