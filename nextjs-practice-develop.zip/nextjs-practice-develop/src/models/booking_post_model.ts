export interface IBookingPost {
	pickUp: string;
	dropOff: string;
	dateStart: string;
	dateEnd: string;
	group: string;
	client: string;
	card: number;
}
