export interface ICard {
	id?: number;
	numberCode: number;
	expirationDate: Date;
	ownerName: string;
	client: string;
}
