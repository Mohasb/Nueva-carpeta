import { ICard } from '~/models/models';
import { IP } from '~/utils/constants/constants';

export async function getCardsByClient(
	client: string,
	token: string
): Promise<ICard[]> {
	return fetch(`${IP}/Card/client/${client}`, {
		headers: {
			Authorization: `Bearer ${token}`,
		},
	})
		.then((response) => {
			if (response.status != 200) throw new Error();
			return response.json();
		})
		.then((res: ICard[]) => res)
		.catch(() => []);
}
