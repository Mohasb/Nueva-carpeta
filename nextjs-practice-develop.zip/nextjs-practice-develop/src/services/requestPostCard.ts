import { ICard } from '~/models/models';
import { INITIAL_CARD_STATE, IP } from '~/utils/constants/constants';

export async function postCard(card: ICard): Promise<ICard> {
	return fetch(`${IP}/Card/`, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
		},
		body: JSON.stringify(card),
	})
		.then((response) => {
			if (response.status != 201) throw new Error();
			return response.json();
		})
		.then((res: ICard) => res)
		.catch(() => INITIAL_CARD_STATE);
}
