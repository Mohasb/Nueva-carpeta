import { IClient } from '~/models/client_model';
import { INITIAL_CLIENT_STATE, IP } from '~/utils/constants/constants';

export async function postClientLogin(
	dni: string,
	password: string
): Promise<IClient> {
	return fetch(`${IP}/Client/login`, {
		method: 'POST',
		headers: { 'Content-type': 'application/json' },
		body: JSON.stringify({
			dni,
			password,
		}),
	})
		.then(async (response) => {
			if (response.status != 200) throw new Error();
			return response.json();
		})
		.then((res: IClient) => res)
		.catch(() => INITIAL_CLIENT_STATE);
}
