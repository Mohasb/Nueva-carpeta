import { IClient } from '~/models/models';
import { INITIAL_CLIENT_STATE, IP } from '~/utils/constants/constants';

export async function updateClient(client: IClient): Promise<IClient> {
	return fetch(`${IP}/Client/${client.dni}`, {
		method: 'PUT',
		headers: {
			'Content-Type': 'application/json',
		},
		body: JSON.stringify(client),
	})
		.then((response) => {
			if (response.status != 201) throw new Error();
			return response.json();
		})
		.then((res: IClient) => res)
		.catch(() => INITIAL_CLIENT_STATE);
}
