import { type PayloadAction, createSlice } from '@reduxjs/toolkit';
import { IClient } from '~/models/models';
import { RootState } from '..';
import { INITIAL_CLIENT_STATE } from '~/utils/constants/constants';

export const loginSlice = createSlice({
	name: 'login',
	initialState: INITIAL_CLIENT_STATE,
	reducers: {
		login: (state, action: PayloadAction<IClient>) => {
			localStorage.setItem('logged__user', JSON.stringify(action.payload));
			return { ...action.payload };
		},
		logout: () => {
			localStorage.removeItem('logged__user');
			return { ...INITIAL_CLIENT_STATE };
		},
	},
});

export const selectLoginState = (state: RootState) => state;

export const { login, logout } = loginSlice.actions;

export default loginSlice.reducer;
