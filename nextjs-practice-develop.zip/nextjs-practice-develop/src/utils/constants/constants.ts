import { IAvailable, IBookingPost, ICard, IClient } from '~/models/models';

export const PORT = '5230';
export const IP = `http://localhost:${PORT}/api`;

export const ID_PICKUP = 'PickUp';
export const ID_DROPOFF = 'DropOff';
export const ID_HOURSTART = 'HourStart';
export const ID_HOUREND = 'HourEnd';
export const TODAY = new Date();
export const TODAY_STRING = TODAY.toISOString().substring(0, 10);
export const INITIAL_AVAILABLE_STATE: IAvailable[] = [];
export const INITIAL_CLIENT_STATE: IClient = {
	id: -1,
	dni: '',
	name: '',
	surname: '',
	email: '',
	password: '',
	phone: 0,
	age: 0,
	address: '',
	cp: 0,
	city: '',
	country: '',
	token: '',
};

export const INITIAL_BOOKING_STATE: IBookingPost = {
	pickUp: '',
	dropOff: '',
	dateStart: '',
	dateEnd: '',
	group: '',
	client: '',
	card: 0,
};

export const INITIAL_CARD_STATE: ICard = {
	id: 0,
	numberCode: 0,
	expirationDate: new Date(Date.parse('01-01-1900')),
	ownerName: '',
	client: '',
};
